Ovo je starija verzija **Preskakanje lopti**. Trenutačno ne uključuje najnovije sadržaje ni korisničke značajke web stranice projekata.  Projekt će biti privremeno dostupan u [ovom](images/Dodgeball.pdf) formatu prije nego se arhivira. 

Trebamo vašu pomoć kako bi ažurirali i preveli ovakve projekte!  Ako ste nam u mogućnosti pomoći, molimo [javite nam se ovdje](https://rpf.io/translators).
