Aceaasta e o versiune mai veche de **Dodgeball**. În prezent, nu include cea mai recentă versiune sau alte capabilități pentru utililizator din cadrul proiectelor de pe site. Acesta va fi accesibil pentru o perioada limitata de timp in acest [format](images/Dodgeball.pdf) aici inainte de a fi arhivat. 

Avem nevoie de ajutorul tău pentru a reînoi și traduce astfel de proiecte!  Dacă poți să ne ajuți, te rugăm [să o faci aici](https://rpf.io/translators).
